print('This is a placeholder file for workflow script 1')
